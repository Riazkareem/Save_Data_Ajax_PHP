<!DOCTYPE HTML>
<html>

<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
</head>

<body>

    <form id="myform" method="post">
        Name: <input type="text" name="name" id="name">
        <input type="button" name="save" value="Save" id="save">
    </form>
    <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    </div>

    <script>
    $(document).ready(function() {
        $('#save').on('click', function(e) {
            e.preventDefault();
            const name = $('#name').val();
            if (name != "") {
                $.ajax({
                    url: 'save.php',
                    type: 'POST',
                    data: {
                        name: name,
                    },
                    success: function(data) {
                        var data = JSON.parse(data);
                        if (data.statusCode == 200) {
                            $("#myform")[0].reset();
                            $("#success").show();
                            $('#success').html('Data added successfully !');
                            window.setTimeout(function() {
                                $(".alert").fadeTo(1000, 0).slideUp(1000,
                                    function() {
                                        $(this).remove();
                                    });
                            }, 3000);
                        } else if (data.statusCode == 201) {
                            alert("Error occured !");
                        }
                    }
                })
            } else {
                alert('Please fill all the field !');
            }

        });
    });
    </script>

</body>

</html>
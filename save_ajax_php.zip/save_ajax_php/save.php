<?php
    $conn = mysqli_connect("localhost", "root", "", "testusers");
    if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    }
    
	$name=$_POST['name'];
    $sql = "INSERT INTO users(name) VALUES ('$name')";
	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn);
?>